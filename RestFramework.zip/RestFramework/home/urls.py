from django.urls import path
from .views import *

urlpatterns = [
    #path('',home),
    #path('student/',post_student),
    #path('get-book/',get_book)
    path('student/',StudentAPI.as_view())
]